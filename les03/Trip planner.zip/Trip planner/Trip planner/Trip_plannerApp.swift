//
//  Trip_plannerApp.swift
//  Trip planner
//
//  Created by Bradley Sander on 01/10/2024.
//

import SwiftUI

@main
struct Trip_plannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
