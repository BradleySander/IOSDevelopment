//
//  FlightInfo.swift
//  Trip planner
//
//  Created by Bradley Sander on 02/10/2024.
//

import Foundation

struct FlightInfo{
    let departureCityCode: String
}
