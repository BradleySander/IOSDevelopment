//
//  Trip_plannerTests.swift
//  Trip plannerTests
//
//  Created by Bradley Sander on 01/10/2024.
//

import Testing

struct Trip_plannerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
